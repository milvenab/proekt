package com.example.todo_list;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.todo_list.db.DBHelper;
import com.example.todo_list.model.Task;

public class AddTask extends AppCompatActivity {
    EditText editTextName;
    EditText editTextStartTime;
    EditText editTextEndTime;
    RadioGroup rg;
    CheckBox checkBoxShowNotification;
    EditText editTextDescription;
    Button addBtn;
    String dateString;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);
        dateString = getIntent().getStringExtra("DATE_EXTRA");
        editTextName = (EditText) findViewById(R.id.name_id);
        editTextStartTime = (EditText) findViewById(R.id.start_time);
        editTextEndTime = (EditText) findViewById(R.id.end_time);
        rg = (RadioGroup) findViewById(R.id.preority_id);
        checkBoxShowNotification = (CheckBox) findViewById(R.id.show_notification);
        editTextDescription = (EditText) findViewById(R.id.description_id);
        addBtn = (Button) findViewById(R.id.add_btn_id);
        addBtn.setOnClickListener(onClick);
    }
    View.OnClickListener onClick=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            DBHelper dbHelper=new DBHelper(AddTask.this);
            String name = editTextName.getText().toString();
            if(!(name.length()>0)){
                Toast.makeText(AddTask.this, "Something is wrong",
                        Toast.LENGTH_LONG).show();
                return;
            }
            String startDateTime = dateString + " " + editTextStartTime.getText().toString();
            String endDateTime = dateString + " " + editTextEndTime.getText().toString();
            boolean isShowNotificationAllow = checkBoxShowNotification.isChecked();
            String priority = getPriority();
            String description = editTextDescription.getText().toString();
            Task t = new Task();
            t.setName(name);
            t.setStartDateTime(startDateTime);
            t.setEndDateTime(endDateTime);
            t.setNotificationAllow(isShowNotificationAllow);
            t.setPriority(priority);
            t.setDescription(description);
            dbHelper.addTask(t,AddTask.this);
            Intent intent = new Intent(AddTask.this, MainActivity.class);
            startActivity(intent);
        }
    };

    private String getPriority() {
        switch (rg.getCheckedRadioButtonId()) {
            case R.id.low_id :
                return "LOW";
            case R.id.middle_id :
                return "MIDDLE";
            case R.id.height_id :
                return "HEIGHT";
            default:
                return "NONE";
        }
    }
}