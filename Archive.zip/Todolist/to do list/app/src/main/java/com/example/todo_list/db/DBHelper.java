package com.example.todo_list.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import com.example.todo_list.model.Task;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    SQLiteDatabase db;
    public static final String LOG = "dbException";

    public static final String DB_NAME = "dbToDoList.db";
    public static final int DB_VERSION = 1;
    //Tale task
    public static final String TABLE_TASK = "task";
    //table task columns
    public static final String TASK_COLUMN_ID = "_id";
    public static final String TASK_COLUMN_NAME = "name";
    public static final String TASK_COLUMN_DESCRIPTION = "description";
    public static final String TASK_COLUMN_START_DATE_TIME = "start_date_time";
    public static final String TASK_COLUMN_END_DATE_TIME = "end_date_time";
    public static final String TASK_COLUMN_PRIORITY = "priority";
    public static final String TASK_COLUMN_IS_NOTIFICATION_ALLOW = "is_notification_allow";
    public static final String CREATE_TABLE_TASK="CREATE TABLE "+TABLE_TASK+"("+
            "'" + TASK_COLUMN_ID + "' INTEGER PRIMARY KEY AUTOINCREMENT," +
            "'" + TASK_COLUMN_NAME + "' TEXT," +
            "'" + TASK_COLUMN_DESCRIPTION + "' TEXT," +
            "'" + TASK_COLUMN_PRIORITY + "' TEXT," +
            "'" + TASK_COLUMN_START_DATE_TIME + "' TEXT," +
            "'" + TASK_COLUMN_END_DATE_TIME + "' TEXT," +
             "'" + TASK_COLUMN_IS_NOTIFICATION_ALLOW + "' INTEGER);";


    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
      sqLiteDatabase.execSQL(CREATE_TABLE_TASK);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
      sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_TASK);
        onCreate(sqLiteDatabase);
    }
public void addTask(Task task, Context context){

    try {
        db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(TASK_COLUMN_NAME, task.getName());
        cv.put(TASK_COLUMN_DESCRIPTION, task.getDescription());
        cv.put(TASK_COLUMN_PRIORITY, task.getPriority());
        cv.put(TASK_COLUMN_END_DATE_TIME, task.getEndDateTime() != null ? task.getEndDateTime().toString() : "");
        cv.put(TASK_COLUMN_START_DATE_TIME, task.getStartDateTime() != null ? task.getStartDateTime().toString() : "");
        cv.put(TASK_COLUMN_IS_NOTIFICATION_ALLOW, task.isNotificationAllow());

        db.insertOrThrow(TABLE_TASK, null, cv);
    }catch (SQLException e){
        Toast.makeText(context, "Something's wrong!!!",
                Toast.LENGTH_LONG).show();
        Log.e(LOG, e.getMessage());
    }finally {
        if(db != null)
            db.close();
    }
}


    public void deleteTask(String task){
        try {
            db =getWritableDatabase();
            db.execSQL("delete from "+TABLE_TASK+" where task ='"+task+"'");
        }catch (SQLException e){
            Log.e(LOG, e.getMessage());
        }finally {
            if (db != null)
                db.close();
        }
    }
    public void updateTask(String task, String newTask, Context context) {
        Cursor c = null;
        ArrayList<Integer> list=new ArrayList<Integer>();
        try {
            String query = "SELECT "+TASK_COLUMN_ID+" FROM " + TABLE_TASK+" where task ='" + task + "'";

            db =getReadableDatabase();
            c = db.rawQuery(query, null);
            if (c.moveToFirst()) {
                do {

                    list.add(c.getInt(c.getColumnIndex(TASK_COLUMN_ID)));


                } while (c.moveToNext());
            }
            db = getWritableDatabase();

            db.execSQL("update " + TABLE_TASK + " set task ='" + newTask + "' where "+TASK_COLUMN_ID+" = " + list.get(0) );
        } catch (SQLException e) {
            Toast.makeText(context, "Something's wrong!!!",
                    Toast.LENGTH_LONG).show();
            Log.e(LOG, e.getMessage());
        } finally {

            if (db != null)
                db.close();
        }
    }

    public ArrayList<String> getAllTask(){
        ArrayList<String> list =new ArrayList<String>();
        Cursor c = null;

        try {
            String query = "SELECT * FROM " + TABLE_TASK;

            db =getReadableDatabase();
            c = db.rawQuery(query, null);
            if (c.moveToFirst()) {
                do {
                    final String name = c.getString(c.getColumnIndex(TASK_COLUMN_NAME));
                    final String priority = c.getString(c.getColumnIndex(TASK_COLUMN_PRIORITY));
                    final String startDateTime = c.getString(c.getColumnIndex(TASK_COLUMN_START_DATE_TIME));
                    final String endDateTime = c.getString(c.getColumnIndex(TASK_COLUMN_END_DATE_TIME));
                    list.add(name + " - " + priority + " - " + startDateTime + " - " + endDateTime);
                } while (c.moveToNext());
            }
        }catch (SQLException e){
            Log.e(LOG, e.getMessage());
        }finally {
            if(c != null)
                c.close();
            if(db != null)
                db.close();
        }
        return list;
    }

}
