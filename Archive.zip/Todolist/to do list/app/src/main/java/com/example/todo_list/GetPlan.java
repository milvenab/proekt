package com.example.todo_list;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GetPlan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_plan);
    }
}