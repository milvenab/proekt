package com.example.todo_list.model;

/**
 * Created by Vlado on 26.11.2017 г..
 */

public class Task {
    private long id;
    private String name;
    private String description;
    private String priority;
    private String startDateTime;
    private String endDateTime;
    private boolean isNotificationAllow;

    public Task() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getStartDateTime() {
        return startDateTime;
    }

    public void setStartDateTime(String startDateTime) {
        this.startDateTime = startDateTime;
    }

    public String getEndDateTime() {
        return endDateTime;
    }

    public void setEndDateTime(String endDateTime) {
        this.endDateTime = endDateTime;
    }

    public boolean isNotificationAllow() {
        return isNotificationAllow;
    }

    public void setNotificationAllow(boolean notificationAllow) {
        isNotificationAllow = notificationAllow;
    }
}
