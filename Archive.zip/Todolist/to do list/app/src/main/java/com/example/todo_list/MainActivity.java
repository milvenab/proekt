package com.example.todo_list;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CalendarView;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class MainActivity extends AppCompatActivity {

    CalendarView calendarView;
    String dateString;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calendarView = (CalendarView) findViewById(R.id.task_calendar);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                dateString = dayOfMonth + "-" + month + "-" + year;
            }
        });

        Button showAllTasksBtn =  (Button) this.findViewById(R.id.show_all_tasks);
        showAllTasksBtn.setOnClickListener(event -> {
            Intent intent = new Intent(this, TaskMain.class);
            startActivity(intent);
        });
        Button addNewTaskBtn =  (Button) this.findViewById(R.id.add_new_task);
        addNewTaskBtn.setOnClickListener(event -> {
            Intent intent = new Intent(this, AddTask.class);
            if(dateString == null) {
                LocalDate date = Instant.ofEpochMilli(calendarView.getDate()).atZone(ZoneId.systemDefault()).toLocalDate();
                dateString = date.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
            }
            intent.putExtra("DATE_EXTRA", dateString);
            startActivity(intent);
        });

        Button getPlanBtn =  (Button) this.findViewById(R.id.get_plan);
        getPlanBtn.setOnClickListener(event -> {
            Intent intent = new Intent(this, GetPlan.class);
            startActivity(intent);
        });

    }
}