package com.example.todo_list;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.todo_list.adapter.MyAdapter;
import com.example.todo_list.db.DBHelper;

import java.util.ArrayList;

public class TaskMain extends AppCompatActivity {
    ListView taskFragmentListView;
    ArrayList<String> items=new ArrayList<String>();
    MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_main);
        DBHelper dbHelper=new DBHelper(this);
        taskFragmentListView=(ListView) findViewById(R.id.taskFragmentListView);
        items.removeAll(items);
        items=dbHelper.getAllTask();
        adapter=new MyAdapter(this,items,R.layout.adapter_task_layout);
        taskFragmentListView.setAdapter(adapter);
    }
}