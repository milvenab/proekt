package com.example.phone_numbers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.phone_numbers.adapter.ContactAdapter;
import com.example.phone_numbers.db.DBHelper;
import com.example.phone_numbers.model.Contact;

import java.util.ArrayList;

public class ContactsActivity extends AppCompatActivity {

    private ListView contactsListView;
    private ArrayList<Contact> items = new ArrayList<>();
    private ContactAdapter adapter;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);
        this.dbHelper = new DBHelper(this);
        this.contactsListView = (ListView) this.findViewById(R.id.contactsListView);
        this.items.clear();
        this.items = dbHelper.getAllContacts();
        this.adapter = new ContactAdapter(this, items, R.layout.adapter_contact_layout);
        this.contactsListView.setAdapter(adapter);
    }
}