package com.example.phone_numbers.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import com.example.phone_numbers.model.Category;
import com.example.phone_numbers.model.Contact;

import java.util.ArrayList;
import java.util.Optional;

/**
 * Created by Vlado on 26.11.2017 г..
 */

public class DBHelper extends SQLiteOpenHelper {
    SQLiteDatabase db;
    public static final String LOG = "dbException";

    public static final String DB_NAME = "dbToDoList.db";
    public static final int DB_VERSION = 1;
    //Tale CONTACT
    public static final String TABLE_CONTACT = "contact";
    //table CONTACT columns
    public static final String CONTACT_COLUMN_ID = "_id";
    public static final String CONTACT_COLUMN_PHONE_NUMBER = "phone_number";
    public static final String CONTACT_COLUMN_NAME = "name";
    public static final String CONTACT_COLUMN_DESCRIPTION = "description";
    public static final String CONTACT_COLUMN_CATEGORY = "category";
    public static final String CREATE_TABLE_CONTACT="CREATE TABLE "+TABLE_CONTACT+"("+
            "'" + CONTACT_COLUMN_ID + "' INTEGER PRIMARY KEY AUTOINCREMENT," +
            "'" + CONTACT_COLUMN_PHONE_NUMBER + "' INTEGER NOT NULL, " +
            "'" + CONTACT_COLUMN_NAME + "' TEXT NOT NULL, " +
            "'" + CONTACT_COLUMN_DESCRIPTION + "' TEXT, " +
            "'" + CONTACT_COLUMN_CATEGORY + "' TEXT NOT NULL)";


    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
      sqLiteDatabase.execSQL(CREATE_TABLE_CONTACT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
      sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_CONTACT);
        onCreate(sqLiteDatabase);
    }
public void addContact(Contact contact, Context context){

    try {
        db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(CONTACT_COLUMN_NAME, contact.getName());
        cv.put(CONTACT_COLUMN_PHONE_NUMBER, contact.getPhoneNumber());
        cv.put(CONTACT_COLUMN_DESCRIPTION, contact.getDescription());
        cv.put(CONTACT_COLUMN_CATEGORY, contact.getCategory().toString());

        db.insertOrThrow(TABLE_CONTACT, null, cv);
    }catch (SQLException e){
        Toast.makeText(context, "Something's wrong!!!",
                Toast.LENGTH_LONG).show();
        Log.e(LOG, e.getMessage());
    }finally {
        if(db != null)
            db.close();
    }
}


    public void deleteContact(long id){
        try {
            db =getWritableDatabase();
            db.execSQL("delete from "+TABLE_CONTACT+" where " + CONTACT_COLUMN_ID + " = " + id);
        }catch (SQLException e){
            Log.e(LOG, e.getMessage());
        }finally {
            if (db != null)
                db.close();
        }
    }
    public void updateContact(long id, Contact newContact, Context context) {
        Cursor c = null;
        try {
            db = getWritableDatabase();
            ContentValues cv = new ContentValues();

            cv.put(CONTACT_COLUMN_NAME, newContact.getName());
            cv.put(CONTACT_COLUMN_PHONE_NUMBER, newContact.getPhoneNumber());
            cv.put(CONTACT_COLUMN_DESCRIPTION, newContact.getDescription());
            cv.put(CONTACT_COLUMN_CATEGORY, newContact.getCategory().toString());
            db.update(TABLE_CONTACT,cv,CONTACT_COLUMN_ID + " = " + id,null);
        } catch (SQLException e) {
            Toast.makeText(context, "Something's wrong!!!",
                    Toast.LENGTH_LONG).show();
            Log.e(LOG, e.getMessage());
        } finally {

            if (db != null)
                db.close();
        }
    }

    public ArrayList<Contact> getAllContacts(){
        ArrayList<Contact> list =new ArrayList<>();
        Cursor c = null;

        try {
            String query = "SELECT * FROM " + TABLE_CONTACT;

            db =getReadableDatabase();
            c = db.rawQuery(query, null);
            if (c.moveToFirst()) {
                do {
                    final Contact contact = new Contact();
                    contact.setId(c.getLong(c.getColumnIndex(CONTACT_COLUMN_ID)));
                    contact.setName(c.getString(c.getColumnIndex(CONTACT_COLUMN_NAME)));
                    contact.setCategory(Category.valueOf(c.getString(c.getColumnIndex(CONTACT_COLUMN_CATEGORY))));
                    contact.setDescription(c.getString(c.getColumnIndex(CONTACT_COLUMN_DESCRIPTION)));
                    contact.setPhoneNumber(c.getInt(c.getColumnIndex(CONTACT_COLUMN_PHONE_NUMBER)));
                    list.add(contact);
                } while (c.moveToNext());
            }
        }catch (SQLException e){
            Log.e(LOG, e.getMessage());
        }finally {
            if(c != null)
                c.close();
            if(db != null)
                db.close();
        }
        return list;
    }

    public Optional<Contact> findById(long id) {
        Cursor c = null;

        try {
            String query = "SELECT * FROM " + TABLE_CONTACT + " WHERE " + CONTACT_COLUMN_ID + " = " + id;

            db =getReadableDatabase();
            c = db.rawQuery(query, null);
            if (c.moveToFirst()) {
                    final Contact contact = new Contact();
                    contact.setId(c.getLong(c.getColumnIndex(CONTACT_COLUMN_ID)));
                    contact.setName(c.getString(c.getColumnIndex(CONTACT_COLUMN_NAME)));
                    contact.setCategory(Category.valueOf(c.getString(c.getColumnIndex(CONTACT_COLUMN_CATEGORY))));
                    contact.setDescription(c.getString(c.getColumnIndex(CONTACT_COLUMN_DESCRIPTION)));
                    contact.setPhoneNumber(c.getInt(c.getColumnIndex(CONTACT_COLUMN_PHONE_NUMBER)));
                    return Optional.of(contact);
            }
        }catch (SQLException e){
            Log.e(LOG, e.getMessage());
        }finally {
            if(c != null)
                c.close();
            if(db != null)
                db.close();
        }
        return Optional.empty();
    }
}
