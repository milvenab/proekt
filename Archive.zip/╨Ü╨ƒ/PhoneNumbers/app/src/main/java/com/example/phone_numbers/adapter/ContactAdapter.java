package com.example.phone_numbers.adapter;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.example.phone_numbers.AddContactActivity;
import com.example.phone_numbers.R;
import com.example.phone_numbers.db.DBHelper;
import com.example.phone_numbers.model.Contact;

import java.util.ArrayList;


public class ContactAdapter extends BaseAdapter implements ListAdapter {
    private Context context;
    private ArrayList<Contact> items;
    int id;
    Dialog customDialog;
    DBHelper dbHelper;

    public ContactAdapter(Context context, ArrayList<Contact> items, int id) {
        this.context = context;
        this.items = items;
        this.id=id;

    }


    @Override


    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(final int i, View view, ViewGroup parent) {

       if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
           view= inflater.inflate(id, null);
        }
       final Contact contact = items.get(i);
           if(id== R.layout.adapter_update_delete_layout) {
               TextView tv = (TextView) view.findViewById(R.id.adapterUpdateDeleteTextView);

               tv.setText(this.getContactDisplayString(contact));
               ImageView updateImageView = (ImageView) view.findViewById(R.id.adapterEditImageView);
               ImageView deleteImageView = (ImageView) view.findViewById(R.id.adapterDeleteImageView);

               View.OnClickListener onClick=new View.OnClickListener() {
                   @Override

                   public void onClick(View v) {
                       dbHelper=new DBHelper(context);
                       if(v.getId() == R.id.adapterDeleteImageView){
                           dbHelper.deleteContact(contact.getId());
                           items.remove(i);
                           notifyDataSetChanged();

                       }else{
                           Intent intent = new Intent(context, AddContactActivity.class);
                           intent.putExtra(AddContactActivity.IS_FOR_UPDATE_EXTRA_KEY, true);
                           intent.putExtra(AddContactActivity.CONTACT_ID_EXTRA_KEY, contact.getId());
                           context.startActivity(intent);
                       }

                   }
               };
               updateImageView.setOnClickListener(onClick);
               deleteImageView.setOnClickListener(onClick);
           }else{
               TextView tv = (TextView) view.findViewById(R.id.adapterContactTextView);
               tv.setTooltipText(contact.getDescription());
               tv.setText(this.getContactDisplayString(contact));
           }
            return view;

    }

    private String getContactDisplayString (final Contact contact){
        return contact.getName() + System.lineSeparator() + contact.getCategory().toString() + System.lineSeparator() + contact.getPhoneNumber();
    }


}
