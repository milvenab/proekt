package com.example.phone_numbers.model;

public enum Category {
    ETC,
    FRIEND,
    FAMILY,
    COLLEAGUES;
}
