package com.example.phone_numbers;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button contactListBtn;
    private Button addContactsBtn;
    private Button removeOrUpdateBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.contactListBtn = (Button) this.findViewById(R.id.contactListBtn);
        this.addContactsBtn = (Button) this.findViewById(R.id.addContactBtn);
        this.removeOrUpdateBtn = (Button) this.findViewById(R.id.removeOrUpdateBtn);
        this.contactListBtn.setOnClickListener(new ChangeActivityOnClickListener<>(ContactsActivity.class));
        this.addContactsBtn.setOnClickListener(new ChangeActivityOnClickListener<>(AddContactActivity.class));
        this.removeOrUpdateBtn.setOnClickListener(new ChangeActivityOnClickListener<>(RemoveOrUpdateContactActivity.class));
    }
    private <T extends Activity> void changeActivity (final Class<T> activityClass) {
        Intent intent = new Intent(this, activityClass);
        startActivity(intent);
    }

    private class ChangeActivityOnClickListener<T extends Activity> implements View.OnClickListener {
        private final Class<T> activityClass;
        public ChangeActivityOnClickListener(final Class<T> activityClass){
            this.activityClass = activityClass;
        }
        @Override
        public void onClick(View v) {
            MainActivity.this.changeActivity(activityClass);
        }
    }
}