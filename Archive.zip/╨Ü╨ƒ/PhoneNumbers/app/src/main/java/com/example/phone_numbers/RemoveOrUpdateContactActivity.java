package com.example.phone_numbers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.phone_numbers.adapter.ContactAdapter;
import com.example.phone_numbers.db.DBHelper;
import com.example.phone_numbers.model.Contact;

import java.util.ArrayList;

public class RemoveOrUpdateContactActivity extends AppCompatActivity {
    private ListView deleteUpdateListView;
    private ContactAdapter adapter;
    private ArrayList<Contact> items = new ArrayList<>();
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_or_update_contact);
        dbHelper = new DBHelper(this);
        deleteUpdateListView= (ListView) this.findViewById(R.id.deleteUpdateListView);
        items = dbHelper.getAllContacts();
        adapter = new ContactAdapter(this,items,R.layout.adapter_update_delete_layout);
        deleteUpdateListView.setAdapter(adapter);
    }
}