package com.example.phone_numbers;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.phone_numbers.db.DBHelper;
import com.example.phone_numbers.model.Category;
import com.example.phone_numbers.model.Contact;

import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AddContactActivity extends AppCompatActivity {
    public static final String IS_FOR_UPDATE_EXTRA_KEY = "IS_FOR_UPDATE";
    public static final String CONTACT_ID_EXTRA_KEY = "CONTACT_ID";
    private EditText editTextName;
    private EditText editTextPhoneNumber;
    private EditText editTextDescription;
    private Spinner spinnerCategory;
    private Button buttonAddOrUpdate;
    private DBHelper dbHelper;
    private boolean isForUpdate;
    private long contactForUpdateId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);
        this.editTextName = (EditText) this.findViewById(R.id.editTextName);
        this.editTextPhoneNumber = (EditText) this.findViewById(R.id.editTextPhoneNumber);
        this.editTextDescription = (EditText) this.findViewById(R.id.editTextTextDescription);
        this.spinnerCategory = (Spinner) this.findViewById(R.id.spinnerCategory);
        this.buttonAddOrUpdate = (Button) this.findViewById(R.id.buttonAddOrUpdate);
        dbHelper = new DBHelper(this);
        this.isForUpdate = this.getIntent().getBooleanExtra(IS_FOR_UPDATE_EXTRA_KEY, false);
        this.UpdateActivityForUpdateContact();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, Stream.of(Category.values()).map(Enum::toString).collect(Collectors.toList()));
        this.spinnerCategory.setAdapter(adapter);
        this.buttonAddOrUpdate.setOnClickListener(this.onClick);
    }

    private void UpdateActivityForUpdateContact() {
        if(this.isForUpdate){
            this.contactForUpdateId = this.getIntent().getLongExtra(CONTACT_ID_EXTRA_KEY, -1);
            if(this.contactForUpdateId == -1){
                Toast.makeText(this, "Something is wrong",
                        Toast.LENGTH_LONG).show();
                this.changeActivity(MainActivity.class);
            } else {
                final Optional<Contact> optionalContact = this.dbHelper.findById(this.contactForUpdateId);
                if(optionalContact.isPresent()) {
                    this.buttonAddOrUpdate.setText("Update");
                    this.editTextName.setText(optionalContact.get().getName());
                    this.editTextPhoneNumber.setText(String.valueOf(optionalContact.get().getPhoneNumber()));
                    this.editTextDescription.setText(optionalContact.get().getDescription());
                    this.spinnerCategory.setSelection(Arrays.asList(Category.values()).indexOf(optionalContact.get().getCategory()));
                }else {
                    Toast.makeText(this, "Something is wrong",
                            Toast.LENGTH_LONG).show();
                    this.changeActivity(MainActivity.class);
                }
            }
        }
    }

    private <T extends Activity> void changeActivity (final Class<T> activityClass) {
        Intent intent = new Intent(this, activityClass);
        startActivity(intent);
    }

    private View.OnClickListener onClick= v -> {
        final String name = this.editTextName.getText().toString();
        final String phoneNumber = this.editTextPhoneNumber.getText().toString();
        final String description = this.editTextDescription.getText().toString();
        final String category = this.spinnerCategory.getSelectedItem().toString();
        if(name.isEmpty() || phoneNumber.isEmpty() || category.isEmpty()){
            Toast.makeText(this, "name, phone number and category can not be null!",
                    Toast.LENGTH_LONG).show();
            return;
        }
        final Contact contact = new Contact();
        contact.setName(name);
        contact.setPhoneNumber(Integer.parseInt(phoneNumber));
        contact.setDescription(description);
        contact.setCategory(Category.valueOf(category));
        if(this.isForUpdate){
            this.dbHelper.updateContact(this.contactForUpdateId, contact, this);
            this.changeActivity(RemoveOrUpdateContactActivity.class);
        } else {
            this.dbHelper.addContact(contact, this);
            this.changeActivity(ContactsActivity.class);
        }
    };
}